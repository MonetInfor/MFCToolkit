﻿using System;
using System.Windows.Forms;
using Express.Common;

namespace Express.UI.BaseSet
{
    public partial class FormOperatorInput : Form
    {
        private FormOperator formOperator;

        public FormOperatorInput()
        {
            InitializeComponent();
        }

        private void FormOperatorInput_Load(object sender, EventArgs e)
        {
            formOperator = (FormOperator) Owner;
            if (Tag.ToString() == "Add")
            {
                txtOperatorCode.Text = CommonClass.BuildCode("Operator", "WHERE OperatorCode <> 'mr'", "OperatorCode",
                                                             "", 4);
            }
            if (Tag.ToString() == "Edit")
            {
                txtOperatorCode.Text = formOperator.dgvOperator.CurrentRow.Cells["OperatorCode"].Value.ToString();
                txtOperatorName.Text = formOperator.dgvOperator.CurrentRow.Cells["OperatorName"].Value.ToString();
                txtPassword.Text = formOperator.dgvOperator.CurrentRow.Cells["Password"].Value.ToString();
                txtAffirmPassword.Text = txtPassword.Text;
                txtPassword.ReadOnly = true;
                txtAffirmPassword.ReadOnly = true;
                if (formOperator.dgvOperator.CurrentRow.Cells["IsFlag"].Value.ToString() == "1")
                {
                    txtOperatorName.ReadOnly = true;
                    btnSave.Enabled = false;
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtOperatorName.Text.Trim()))
            {
                MessageBox.Show("操作名称不许为空！", "软件提示");
                txtOperatorName.Focus();
                return;
            }
            if (String.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("操作密码不许为空！", "软件提示");
                txtPassword.Focus();
                return;
            }
            if (txtPassword.Text != txtAffirmPassword.Text)
            {
                MessageBox.Show("确认密码与操作密码不相同！", "软件提示");
                txtAffirmPassword.Focus();
                return;
            }
            if (Tag.ToString() == "Add")
            {
                DataGridViewRow dataGridViewRow = CommonClass.AddDataGridViewRow(formOperator.dgvOperator,
                                                                                 formOperator.bsOperator);
                dataGridViewRow.Cells["OperatorCode"].Value = txtOperatorCode.Text;
                dataGridViewRow.Cells["OperatorName"].Value = txtOperatorName.Text.Trim();
                dataGridViewRow.Cells["Password"].Value = txtPassword.Text;
                dataGridViewRow.Cells["IsFlag"].Value = "0";
                if (CommonClass.Commit(formOperator.dgvOperator, formOperator.bsOperator))
                {
                    if (MessageBox.Show("保存成功，是否继续添加？", "软件提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) ==
                        DialogResult.Yes)
                    {
                        txtOperatorCode.Text = CommonClass.BuildCode("Operator", "WHERE OperatorCode <> 'mr'",
                                                                     "OperatorCode", "", 4);
                        txtOperatorName.Text = "";
                        txtPassword.Text = "";
                        txtAffirmPassword.Text = "";
                    }
                    else
                    {
                        Close();
                    }
                }
                else
                {
                    MessageBox.Show("保存失败！", "软件提示");
                }
            }
            if (Tag.ToString() == "Edit")
            {
                DataGridViewRow dataGridViewRow = formOperator.dgvOperator.CurrentRow;
                dataGridViewRow.Cells["OperatorName"].Value = txtOperatorName.Text.Trim();
                if (CommonClass.Commit(formOperator.dgvOperator, formOperator.bsOperator))
                {
                    MessageBox.Show("保存成功！", "软件提示");
                    Close();
                }
                else
                {
                    MessageBox.Show("保存失败！", "软件提示");
                }
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}