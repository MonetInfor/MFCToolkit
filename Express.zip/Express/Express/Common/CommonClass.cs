﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;
using Express.CustomControl;
using Express.DAL;

namespace Express.Common
{
    public class CommonClass
    {
        private static SqlDataAdapter adapter;

        public static DataTable GetDataTable(string strTableName, string strWhere)
        {
            string strSql = "SELECT * FROM " + strTableName + " " + strWhere;

            adapter = new SqlDataAdapter(strSql, DataOperate.GetConnection());
            new SqlCommandBuilder(adapter);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            return dataTable;
        }

        public static bool Commit(DataGridView dataGridView, BindingSource bindingSource)
        {
            dataGridView.EndEdit();
            bindingSource.EndEdit();
            DataTable dataTable = bindingSource.DataSource as DataTable;
            if (adapter.Update(dataTable) > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void ShowDialogForm(Type formType, string strTag, Form formParent)
        {
            Form form = Activator.CreateInstance(formType) as Form;
            form.Tag = strTag;
            form.Owner = formParent;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.ShowDialog();
        }

        public static void ShowDialogForm(Type formType, CTextBox cTextBox, Form formParent)
        {
            Form form = Activator.CreateInstance(formType) as Form;
            form.Tag = cTextBox;
            form.Owner = formParent;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.ShowDialog();
        }

        public static void ShowFormByMdiParent(Type typeForm, Form formMdiParent)
        {
            Form form = Activator.CreateInstance(typeForm) as Form;
            form.MdiParent = formMdiParent;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Show();
        }

        public static string BuildCode(string strTableName, string strWhere, string strCodeColumn, string strHeader,
                                       int intLength)
        {
            string strSql = "SELECT MAX(" + strCodeColumn + ") FROM " + strTableName + " " + strWhere;
            string strMaxCode = DataOperate.GetSingleObject(strSql) as string;
            if (String.IsNullOrEmpty(strMaxCode))
            {
                strMaxCode = strHeader + FormatString(intLength);
            }
            string strMaxSeqNum = strMaxCode.Substring(strHeader.Length);
            return strHeader + (Convert.ToInt32(strMaxSeqNum) + 1).ToString(FormatString(intLength));
        }

        public static string FormatString(int length)
        {
            string strFormat = String.Empty;
            for (int i = 0; i < length; i++)
            {
                strFormat = strFormat + "0";
            }
            return strFormat;
        }

        public static void InputNumeric(KeyPressEventArgs e, Control con)
        {
            if (String.IsNullOrEmpty(con.Text) && e.KeyChar.ToString() == ".")
            {
                e.Handled = true;
            }

            if (con.Text.Contains(".") && e.KeyChar.ToString() == ".")
            {
                e.Handled = true;
            }

            if (!Char.IsDigit(e.KeyChar) && e.KeyChar.ToString() != "." && e.KeyChar.ToString() != "")
            {
                e.Handled = true;
            }
        }

        public static void InputInteger(KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar.ToString() != "")
            {
                e.Handled = true;
            }
        }

        public static void SetFocus(KeyEventArgs e, Control con)
        {
            if (e.KeyCode == Keys.Enter)
            {
                con.Focus();
            }
        }

        public static DataGridViewRow AddDataGridViewRow(DataGridView dataGridView, BindingSource bindingSource)
        {
            DataTable dataTable = bindingSource.DataSource as DataTable;
            DataRow dataRow = dataTable.NewRow();

            dataTable.Rows.Add(dataRow);
            bindingSource.DataSource = dataTable;
            dataGridView.DataSource = bindingSource;
            int intRowIndex = dataGridView.RowCount - 1;
            return dataGridView.Rows[intRowIndex];
        }

        public static void DataGridViewReset(DataGridView dataGridView)
        {
            if (dataGridView.DataSource != null)
            {
                if (dataGridView.DataSource.GetType() == typeof (DataTable))
                {
                    DataTable dataTable = dataGridView.DataSource as DataTable;
                    dataTable.Clear();
                }
                if (dataGridView.DataSource.GetType() == typeof (BindingSource))
                {
                    BindingSource bindingSource = dataGridView.DataSource as BindingSource;
                    DataTable dataTable = bindingSource.DataSource as DataTable;
                    dataTable.Clear();
                }
            }
        }

        public static byte[] GetBytesByImage(Image image)
        {
            MemoryStream ms = new MemoryStream();
            new BinaryFormatter().Serialize(ms, image);
            return ms.GetBuffer();
        }

        public static Image GetImageByBytes(byte[] buffer)
        {
            MemoryStream ms = new MemoryStream(buffer);
            return new BinaryFormatter().Deserialize(ms) as Image;
        }

        public static bool GetCheckedValue(string strFlag)
        {
            if (strFlag == "1")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static string GetFlagValue(CheckState check)
        {
            if (check == CheckState.Checked)
            {
                return "1";
            }
            else
            {
                return "0";
            }
        }

        public static void ListBoxBindDataSource(ListBox listBox, string strValueColumn, string strDisplayColumn,
                                                 string strSql, string strTableName)
        {
            listBox.BeginUpdate();
            listBox.DataSource = DataOperate.GetDataTable(strSql);
            listBox.DisplayMember = strDisplayColumn;
            listBox.ValueMember = strValueColumn;
            listBox.EndUpdate();
        }

        public static bool IsExistConstraint(string strPrimaryTable, string strPrimaryValue)
        {
            bool booIsExist = false;

            SqlParameter parameter = new SqlParameter("@PrimaryTable", SqlDbType.VarChar) {Value = strPrimaryTable};

            List<SqlParameter> parameters = new List<SqlParameter> {parameter};

            SqlParameter[] inputParameters = parameters.ToArray();

            DataTable dt = DataOperate.GetDataTable("QueryForeignConstraint", inputParameters);

            foreach (DataRow dataRow in dt.Rows)
            {
                string strForeignTable = dataRow["ForeignTable"].ToString();
                string strForeignColumn = dataRow["ForeignColumn"].ToString();
                string strSql = "SELECT " + strForeignColumn + " FROM " + strForeignTable + " WHERE " + strForeignColumn +
                                " = '" + strPrimaryValue + "'";
                SqlDataReader dataReader = DataOperate.GetDataReader(strSql);

                if (dataReader.HasRows)
                {
                    booIsExist = true;
                    dataReader.Close();
                    break;
                }

                dataReader.Close();
            }

            return booIsExist;
        }

        public static bool IsExistExpressBillCode(string strExpressBillCode, string strBillTypeCode)
        {
            SqlParameter paramExpressBillCode = new SqlParameter("@ExpressBillCode", SqlDbType.VarChar)
                                                    {Value = strExpressBillCode};


            SqlParameter paramBillTypeCode = new SqlParameter("@BillTypeCode", SqlDbType.VarChar)
                                                 {Value = strBillTypeCode};


            List<SqlParameter> parameters = new List<SqlParameter> {paramExpressBillCode, paramBillTypeCode};

            SqlParameter[] inputParameters = parameters.ToArray();
            DataTable dt = DataOperate.GetDataTable("IsExistExpressBillCode", inputParameters);
            if (Convert.ToInt32(dt.Rows[0][0]) > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}