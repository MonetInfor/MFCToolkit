﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Windows.Forms;
using Express.Common;
using Express.CustomControl;
using Express.DAL;

namespace Express.UI.Express
{
    public partial class FormBillPrint : Form
    {
        private CTextBox cTextBox;
        private CTextBox ctxtExpressBillCode;
        private DataTable dtBillTemplate;
        private DataTable dtBillType;
        private float fDpiX;
        private float fDpiY;

        public FormBillPrint()
        {
            InitializeComponent();
        }

        public List<CTextBox> GetCTextBoxes(Control control)
        {
            List<CTextBox> cTextBoxes = new List<CTextBox>();
            foreach (Control c in control.Controls)
            {
                if (c.GetType() == typeof (CTextBox))
                {
                    cTextBoxes.Add((CTextBox) c);
                }
                if (c.GetType() == typeof (GroupBox))
                {
                    GetCTextBoxes(c);
                }
                if (c.GetType() == typeof (SplitContainer))
                {
                    GetCTextBoxes(c);
                }
                if (c.GetType() == typeof (SplitterPanel))
                {
                    GetCTextBoxes(c);
                }
            }
            return cTextBoxes;
        }

        public void DisposeAllCTextBoxes(Control control)
        {
            Control.ControlCollection controls = control.Controls;
            int intCount = controls.Count;
            for (int i = 0; i < intCount; i++)
            {
                if (controls[i].GetType() == typeof (GroupBox))
                {
                    DisposeAllCTextBoxes(controls[i]);
                }
                if (controls[i].GetType() == typeof (SplitContainer))
                {
                    DisposeAllCTextBoxes(controls[i]);
                }
                if (controls[i].GetType() == typeof (SplitterPanel))
                {
                    DisposeAllCTextBoxes(controls[i]);
                }
                if (controls[i].GetType() == typeof (CTextBox))
                {
                    controls[i].Dispose();
                    i -= 1;
                    intCount -= 1;
                }
            }
        }

        public void InitTemplate(DataTable dt)
        {
            List<CTextBox> cTextBoxs = new List<CTextBox>();
            DisposeAllCTextBoxes(this);
            foreach (DataRow dataRow in dt.Rows)
            {
                cTextBox = new CTextBox
                               {
                                   ContextMenuStrip = null,
                                   ControlId = Convert.ToInt32(dataRow["ControlId"]),
                                   IsFlag = dataRow["IsFlag"].ToString(),
                                   Location = new Point(Convert.ToInt32(dataRow["X"]), Convert.ToInt32(dataRow["Y"])),
                                   Size =
                                       new Size(Convert.ToInt32(dataRow["Width"]), Convert.ToInt32(dataRow["Height"])),
                                   ControlName = dataRow["ControlName"].ToString(),
                                   DefaultValue = dataRow["DefaultValue"].ToString()
                               };
                cTextBox.Text = cTextBox.DefaultValue;
                cTextBox.TurnControlName = dataRow["TurnControlName"].ToString();
                if (cTextBox.IsFlag == "1")
                {
                    ctxtExpressBillCode = cTextBox;
                    cTextBox.Font = new Font(new FontFamily("宋体"), 9, FontStyle.Bold);
                    cTextBox.MaxLength = Convert.ToInt32(dtBillType.Rows[0]["BillCodeLength"]);
                    cTextBox.Text = CommonClass.BuildCode("BillText", "WHERE ControlId = '" + cTextBox.ControlId + "'",
                                                          "ExpressBillCode", "", cTextBox.MaxLength);
                }
                cTextBox.KeyDown += ctxt_KeyDown;
                splitContainer1.Panel1.Controls.Add(cTextBox);
                cTextBoxs.Add(cTextBox);
            }
            splitContainer1.Panel1.Controls.Add(pbxBillPicture);
            if (!cTextBoxs.Any(itm => itm.IsFlag == "1"))
            {
                toolPrint.Enabled = false;
                MessageBox.Show("当前模板未设置快递单号输入框，所以无法打印", "信息提示");
            }
            else
            {
                toolPrint.Enabled = true;
            }
        }

        private void ctxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                CTextBox ctxtTurnCtrl = null;
                CTextBox ctxtCurCtrl = null;
                List<CTextBox> ctxts = GetCTextBoxes(splitContainer1.Panel1);
                foreach (CTextBox ctxt in ctxts)
                {
                    if (ctxt.Focused)
                    {
                        ctxtCurCtrl = ctxt;
                        break;
                    }
                }
                ctxtTurnCtrl = ctxts.Find(number => number.ControlName == ctxtCurCtrl.TurnControlName);
                if (ctxtTurnCtrl != null)
                {
                    ctxtTurnCtrl.Focus();
                }
            }
        }

        public void BuildImageData(string strBillTypeCode)
        {
            dtBillType =
                DataOperate.GetDataTable("SELECT * FROM BillType WHERE BillTypeCode = '" + strBillTypeCode + "'");
            dtBillTemplate =
                DataOperate.GetDataTable("SELECT * FROM BillTemplate WHERE BillTypeCode = '" + strBillTypeCode + "'");
        }

        private float MillimetersToPixel(float fValue, float fDPI)
        {
            return (fValue/25.4f)*fDPI;
        }

        private void FormBillPrint_Load(object sender, EventArgs e)
        {
            fDpiX = CreateGraphics().DpiX;
            fDpiY = CreateGraphics().DpiY;
            CommonClass.ListBoxBindDataSource(lbxBillTypeCode, "BillTypeCode", "BillTypeName",
                                              "SELECT * FROM BillType WHERE IsEnabled = '1'", "BillType");
            if (lbxBillTypeCode.Items.Count > 0)
            {
                BuildImageData(lbxBillTypeCode.SelectedValue.ToString());
                InitTemplate(dtBillTemplate);
            }
            else
            {
                toolPrint.Enabled = false;
            }
        }

        private void pbxBillPicture_Paint(object sender, PaintEventArgs e)
        {
            if (lbxBillTypeCode.Items.Count > 0)
            {
                Image img = CommonClass.GetImageByBytes(dtBillType.Rows[0]["BillPicture"] as byte[]);
                Point point = new Point(0, 0);
                SizeF newSize = new SizeF(MillimetersToPixel(Convert.ToInt32(dtBillType.Rows[0]["BillWidth"]), fDpiX),
                                          MillimetersToPixel(Convert.ToInt32(dtBillType.Rows[0]["BillHeight"]), fDpiY));
                RectangleF NewRect = new RectangleF(point, newSize);
                SizeF oldSize = new SizeF(img.Width, img.Height);
                RectangleF OldRect = new RectangleF(point, oldSize);
                e.Graphics.DrawImage(img, NewRect, OldRect, GraphicsUnit.Pixel);
            }
        }

        private void lbxBillTypeCode_DoubleClick(object sender, EventArgs e)
        {
            if (lbxBillTypeCode.Items.Count > 0)
            {
                BuildImageData(lbxBillTypeCode.SelectedValue.ToString());
                Refresh();
                InitTemplate(dtBillTemplate);
            }
        }

        private void toolPrint_Click(object sender, EventArgs e)
        {
            List<string> strSqls = new List<string>();
            List<CTextBox> ctxts = GetCTextBoxes(splitContainer1.Panel1);
            foreach (CTextBox ctxt in ctxts)
            {
                if (ctxt.IsFlag == "1")
                {
                    if (String.IsNullOrEmpty(ctxt.Text.Trim()))
                    {
                        MessageBox.Show("单据号不许为空！", "软件提示");
                        ctxt.Focus();
                        return;
                    }
                    else
                    {
                        if (ctxt.Text.Trim().Length != ctxt.MaxLength)
                        {
                            MessageBox.Show("单据号位数不正确！", "软件提示");
                            ctxt.Focus();
                            return;
                        }
                    }
                    if (CommonClass.IsExistExpressBillCode(ctxt.Text.Trim(), lbxBillTypeCode.SelectedValue.ToString()))
                    {
                        MessageBox.Show("该单据号已经存在！", "软件提示");
                        ctxt.Focus();
                        return;
                    }
                }
                else
                {
                    if (String.IsNullOrEmpty(ctxt.Text.Trim()))
                    {
                        if (
                            MessageBox.Show(ctxt.ControlName + "为空，是否继续", "软件提示", MessageBoxButtons.YesNo,
                                            MessageBoxIcon.Exclamation) == DialogResult.No)
                        {
                            ctxt.Focus();
                            return;
                        }
                    }
                }

                string strSql =
                    "INSERT INTO BillText (BillTypeCode, ControlId, ExpressBillCode, ControlText) VALUES ('" +
                    lbxBillTypeCode.SelectedValue + "','" + ctxt.ControlId + "','" + ctxtExpressBillCode.Text.Trim() +
                    "','" + ctxt.Text.Trim() + "')";
                strSqls.Add(strSql);
            }
            if (strSqls.Count > 0)
            {
                if (DataOperate.ExecDataBySqls(strSqls))
                {
                    Margins margin = new Margins(0, 0, 0, 0);
                    pd.DefaultPageSettings.Margins = margin;
                    PaperSize pageSize = new PaperSize("快递单打印",
                                                       Convert.ToInt32(
                                                           MillimetersToPixel(
                                                               Convert.ToInt32(dtBillType.Rows[0]["BillWidth"]), fDpiX)),
                                                       Convert.ToInt32(
                                                           MillimetersToPixel(
                                                               Convert.ToInt32(dtBillType.Rows[0]["BillHeight"]), fDpiY)));
                    pd.DefaultPageSettings.PaperSize = pageSize;
                    pd.Print();
                }
                else
                {
                    MessageBox.Show("保存失败，无法打印", "软件提示");
                    return;
                }
            }
        }

        private void toolExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pd_PrintPage(object sender, PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            Font font = new Font("宋体", 12, GraphicsUnit.Pixel);
            Brush brush = new SolidBrush(Color.Black);
            List<CTextBox> ctxts = GetCTextBoxes(splitContainer1.Panel1);
            foreach (CTextBox ctxt in ctxts)
            {
                if (ctxt.IsFlag != "1")
                {
                    g.DrawString(ctxt.Text, font, brush, ctxt.Location.X, ctxt.Location.Y);
                }
            }
            foreach (CTextBox ctxt in ctxts)
            {
                if (ctxt.IsFlag == "1")
                {
                    ctxt.Text = CommonClass.BuildCode("BillText", "WHERE ControlId = '" + ctxt.ControlId + "'",
                                                      "ExpressBillCode", "", ctxt.MaxLength);
                }
                else
                {
                    if (String.IsNullOrEmpty(ctxt.DefaultValue))
                    {
                        ctxt.Text = "";
                    }
                    else
                    {
                        ctxt.Text = ctxt.DefaultValue;
                    }
                }
            }
        }

        private void pd_QueryPageSettings(object sender, QueryPageSettingsEventArgs e)
        {
        }
    }
}