﻿using System;
using System.Windows.Forms;
using Express.Common;
using Express.DAL;

namespace Express.UI.BaseSet
{
    public partial class FormAmendPassword : Form
    {
        public FormAmendPassword()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            errAffirmPassword.Clear();
            errOldPassword.Clear();
            errPassword.Clear();
            if (String.IsNullOrEmpty(txtOldPassword.Text))
            {
                errOldPassword.SetError(txtOldPassword, "原密码不能为空！");
                txtOldPassword.Focus();
                return;
            }
            else
            {
                if (txtOldPassword.Text != GlobalProperty.Password)
                {
                    errOldPassword.SetError(txtOldPassword, "原密码不正确！");
                    txtOldPassword.Focus();
                    return;
                }
            }
            if (String.IsNullOrEmpty(txtPassword.Text))
            {
                errPassword.SetError(txtPassword, "新密码不能为空！");
                txtPassword.Focus();
                return;
            }
            if (txtAffirmPassWord.Text != txtPassword.Text)
            {
                errAffirmPassword.SetError(txtAffirmPassWord, "确认密码与新密码不相同！");
                txtAffirmPassWord.Focus();
                return;
            }
            string strSql = "UPDATE Operator SET Password = '" + txtPassword.Text + "' WHERE OperatorCode = '" +
                            GlobalProperty.OperatorCode + "'";
            if (DataOperate.ExecDataBySql(strSql) > 0)
            {
                MessageBox.Show("密码修改成功！", "软体提示");
                Close();
            }
            else
            {
                MessageBox.Show("密码修改失败！", "软体提示");
            }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}