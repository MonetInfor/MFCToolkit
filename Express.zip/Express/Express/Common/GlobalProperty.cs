﻿namespace Express.Common
{
    public class GlobalProperty
    {
        private static string _operatorCode;

        private static string operatorName;

        private static string password;

        private static string isFlag;

        public static string OperatorCode
        {
            get { return _operatorCode; }
            set { _operatorCode = value; }
        }

        public static string OperatorName
        {
            get { return operatorName; }
            set { operatorName = value; }
        }

        public static string Password
        {
            get { return password; }
            set { password = value; }
        }

        public static string IsFlag
        {
            get { return isFlag; }
            set { isFlag = value; }
        }
    }
}