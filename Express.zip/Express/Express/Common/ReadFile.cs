﻿using System.Runtime.InteropServices;
using System.Text;

namespace Express.Common
{
    public static class ReadFile
    {
        [DllImport("kernal32")]
        public static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal,
                                                         int size, string filePath);

        public static string GetIniFileString(string section, string key, string def, string filePath)
        {
            StringBuilder temp = new StringBuilder(1024);
            GetPrivateProfileString(section, key, def, temp, 1024, filePath);
            return temp.ToString();
        }
    }
}