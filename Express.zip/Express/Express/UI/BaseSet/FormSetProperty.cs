﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Express.Common;
using Express.CustomControl;

namespace Express.UI.BaseSet
{
    public partial class FormSetProperty : Form
    {
        private CTextBox ctxtCur;
        private FormSetTemplate formSetTemplate;

        public FormSetProperty()
        {
            InitializeComponent();
        }

        public List<CTextBox> GetCTextBoxes(Control ctrlParent)
        {
            List<CTextBox> ctxts = new List<CTextBox>();
            foreach (Control ctrl in ctrlParent.Controls)
            {
                if (ctrl.GetType() == typeof (CTextBox))
                {
                    ctxts.Add((CTextBox) ctrl);
                }
                if (ctrl.GetType() == typeof (GroupBox))
                {
                    GetCTextBoxes(ctrl);
                }
            }
            return ctxts;
        }


        private void FormSetProperty_Load(object sender, EventArgs e)
        {
            formSetTemplate = (FormSetTemplate) Owner;
            if (Tag.GetType() == typeof (CTextBox))
            {
                ctxtCur = Tag as CTextBox;
                txtDefaultValue.Visible = true;
                txtControlName.Text = ctxtCur.ControlName;
                txtDefaultValue.Text = ctxtCur.DefaultValue;

                cbxTurnControlName.DataSource = GetCTextBoxes(formSetTemplate);
                cbxTurnControlName.DisplayMember = "ControlName";
                cbxTurnControlName.ValueMember = "ControlName";

                if (!String.IsNullOrEmpty(ctxtCur.TurnControlName))
                {
                    cbxTurnControlName.SelectedValue = ctxtCur.TurnControlName;
                }
                else
                {
                    cbxTurnControlName.SelectedIndex = -1;
                }
                chbIsFlag.Checked = CommonClass.GetCheckedValue(ctxtCur.IsFlag);
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtControlName.Text.Trim()))
            {
                MessageBox.Show("名称不许为空！", "软件提示");
                txtControlName.Focus();
                return;
            }
            List<CTextBox> ctxts = GetCTextBoxes(formSetTemplate);
            foreach (CTextBox ctxt in ctxts)
            {
                if (!ctxt.Equals(ctxtCur))
                {
                    if (ctxt.ControlName == txtControlName.Text.Trim())
                    {
                        MessageBox.Show("名称重复，请重新设置！", "软件提示");
                        txtControlName.Focus();
                        return;
                    }
                }
            }

            ctxtCur.ControlName = txtControlName.Text.Trim();
            ctxtCur.Text = txtControlName.Text.Trim();

            ctxtCur.DefaultValue = txtDefaultValue.Text.Trim();

            if (cbxTurnControlName.SelectedValue != null)
            {
                ctxtCur.TurnControlName = cbxTurnControlName.SelectedValue.ToString();
            }

            ctxtCur.IsFlag = CommonClass.GetFlagValue(chbIsFlag.CheckState);
            ctxtCur.BackColor = Color.Red;
            Close();
        }

        private void chbIsFlag_CheckedChanged(object sender, EventArgs e)
        {
            if (chbIsFlag.Checked)
            {
                List<CTextBox> ctxts = GetCTextBoxes(formSetTemplate);
                foreach (CTextBox ctxt in ctxts)
                {
                    if (!ctxt.Equals(ctxtCur))
                    {
                        if (ctxt.IsFlag == "1")
                        {
                            MessageBox.Show("已存在快递单号输入框！", "软件提示");
                            chbIsFlag.Checked = false;
                            break;
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}