﻿using System;
using System.Windows.Forms;
using Express.Common;
using Express.UI.BaseSet;
using Express.UI.Express;

namespace Express
{
    public partial class AppForm : Form
    {
        public AppForm()
        {
            InitializeComponent();
        }

        private void menuItemSetBill_Click(object sender, EventArgs e)
        {
            CommonClass.ShowFormByMdiParent(typeof (FormBillType), this);
        }

        private void menuItemBillPrint_Click(object sender, EventArgs e)
        {
            CommonClass.ShowFormByMdiParent(typeof (FormBillPrint), this);
        }

        private void menuItemSetOperator_Click(object sender, EventArgs e)
        {
            CommonClass.ShowFormByMdiParent(typeof (FormOperator), this);
        }

        private void menuItemAmendPass_Click(object sender, EventArgs e)
        {
            CommonClass.ShowFormByMdiParent(typeof (FormAmendPassword), this);
        }

        private void menuItemBillQuery_Click(object sender, EventArgs e)
        {
            CommonClass.ShowFormByMdiParent(typeof (FormExpressBill), this);
        }

        private void menuItemExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AppForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
            Dispose();
        }
    }
}