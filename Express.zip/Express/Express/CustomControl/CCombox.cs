﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using Express.Common;
using Express.DAL;
using Express.UI.BaseSet;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Express.CustomControl
{
    public partial class CCombox : ComboBox
    {
        public CCombox()
        {
            InitializeComponent();
        }

        public CCombox(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }
    }
}
