﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using Express.Common;
using Express.DAL;

namespace Express
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void txtCode_KeyDown(object sender, KeyEventArgs e)
        {
            CommonClass.SetFocus(e, txtPwd);
        }

        private void txtPwd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                picLogin_Click(sender, e);
            }
        }

        private void picLogin_Click(object sender, EventArgs e)
        {
            SqlDataReader sqlDataReader = null;
            if (String.IsNullOrEmpty(txtCode.Text.Trim()))
            {
                MessageBox.Show("登录用户不许为空！", "软件提示");
                txtCode.Focus();
                return;
            }
            if (String.IsNullOrEmpty(txtPwd.Text))
            {
                MessageBox.Show("登录密码不许为空！", "软件提示");
                txtPwd.Focus();
                return;
            }
            string strSql = "SELECT * FROM Operator WHERE OperatorCode = '" + txtCode.Text.Trim() + "'";
            try
            {
                sqlDataReader = DataOperate.GetDataReader(strSql);
                if (!sqlDataReader.HasRows)
                {
                    MessageBox.Show("登录用户不正确！", "软件提示");
                    txtCode.Focus();
                }
                else
                {
                    sqlDataReader.Read();
                    if (txtPwd.Text != sqlDataReader["Password"].ToString())
                    {
                        MessageBox.Show("登录密码不正确！", "软件提示");
                        txtPwd.Focus();
                    }
                    else
                    {
                        GlobalProperty.OperatorCode = sqlDataReader["OperatorCode"].ToString();
                        GlobalProperty.OperatorName = sqlDataReader["OperatorName"].ToString();
                        GlobalProperty.Password = sqlDataReader["Password"].ToString();
                        GlobalProperty.IsFlag = sqlDataReader["IsFlag"].ToString();
                        Hide();
                        AppForm formApp = new AppForm();
                        formApp.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "软件提示");
            }
            finally
            {
                sqlDataReader.Close();
            }
        }

        private void picReset_Click(object sender, EventArgs e)
        {
            txtCode.Text = "";
            txtPwd.Text = "";
        }

        private void picQuit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}