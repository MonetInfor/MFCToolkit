﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
namespace Express.DAL
{
    public static class DataOperate
    {
        private static readonly string StrCon = ConfigurationManager.AppSettings["Express"];

        public static SqlConnection GetConnection()
        {
             return new SqlConnection(StrCon);
            // return  StrCon;
        }
        public static string GetConnectionString()
        {
            return StrCon;
        }
        public static int ExecDataBySql(string strSql)
        {
            return SqlHelper.ExecuteNonQuery(GetConnection(), CommandType.Text, strSql);
        }

        public static bool ExecDataBySqls(List<string> strSqls)
        {
            bool isSucceed;

            SqlConnection connection = GetConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            connection.Open();
            SqlTransaction transaction = connection.BeginTransaction();
            try
            {
                command.Transaction = transaction;
                foreach (string strSql in strSqls)
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = strSql;
                    command.ExecuteNonQuery();
                }
                transaction.Commit();
                isSucceed = true;
            }
            catch (Exception)
            {
                transaction.Rollback();
                isSucceed = false;
            }
            finally
            {
                connection.Close();
            }
            return isSucceed;
        }

        public static DataSet GetDataSet(string strSql)
        {
            return SqlHelper.ExecuteDataset(GetConnection(), CommandType.Text, strSql);
        }

        public static SqlDataReader GetDataReader(string strSql)
        {
            return SqlHelper.ExecuteReader(GetConnection(), CommandType.Text, strSql);
        }

        public static object GetSingleObject(string strSql)
        {
            return SqlHelper.ExecuteScalar(GetConnection(), CommandType.Text, strSql);
        }

        public static DataTable GetDataTable(string strSql)
        {
          //  return SqlHelper.ExecuteDataSet(GetConnection(), CommandType.Text, strSql).Tables[0];
              return SqlHelper.ExecuteDataset(GetConnection(), CommandType.Text, strSql).Tables[0];
            //return new DataTable();
        }

        public static DataTable GetDataTable(string procedureName, SqlParameter[] sqlParameters)
        {
            return SqlHelper.ExecuteDataset(GetConnection(), CommandType.StoredProcedure, procedureName, sqlParameters).Tables[0];

            // return new DataTable();
        }
    }
}