﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Windows.Forms;
using Express.Common;
using Express.CustomControl;
using Express.DAL;

namespace Express.UI.Express
{
    public partial class FormBrowseBill : Form
    {
        private CTextBox ctxt;
        private CTextBox ctxtExpressBillCode;
        private DataTable dtBillType;
        private float fDpiX;
        private float fDpiY;
        private FormExpressBill formExpressBill;
        private string strBillTypeCode;
        private string strExpressBillCode;

        public FormBrowseBill()
        {
            InitializeComponent();
        }

        public List<CTextBox> GetCTextBoxes(Control control)
        {
            List<CTextBox> cTextBoxes = new List<CTextBox>();
            foreach (Control c in control.Controls)
            {
                if (c.GetType() == typeof (CTextBox))
                {
                    cTextBoxes.Add((CTextBox) c);
                }
                if (c.GetType() == typeof (GroupBox))
                {
                    GetCTextBoxes(c);
                }
                if (c.GetType() == typeof (SplitContainer))
                {
                    GetCTextBoxes(c);
                }
                if (c.GetType() == typeof (SplitterPanel))
                {
                    GetCTextBoxes(c);
                }
            }
            return cTextBoxes;
        }

        public void DrawImage(Graphics graphics)
        {
            Image img = CommonClass.GetImageByBytes(dtBillType.Rows[0]["BillPicture"] as byte[]);
            Point point = new Point(0, 0);
            SizeF newSize = new SizeF(MillimetersToPixel(Convert.ToInt32(dtBillType.Rows[0]["BillWidth"]), fDpiX),
                                      MillimetersToPixel(Convert.ToInt32(dtBillType.Rows[0]["BillHeight"]), fDpiY));
            RectangleF NewRect = new RectangleF(point, newSize);
            SizeF oldSize = new SizeF(img.Width, img.Height);
            RectangleF OldRect = new RectangleF(point, oldSize);
            graphics.DrawImage(img, NewRect, OldRect, GraphicsUnit.Pixel);

            if (newSize.Width > Width || newSize.Height > Height)
            {
                Size size =
                    new Size(
                        Convert.ToInt32(MillimetersToPixel(Convert.ToInt32(dtBillType.Rows[0]["BillWidth"]), fDpiX)),
                        Convert.ToInt32(MillimetersToPixel(Convert.ToInt32(dtBillType.Rows[0]["BillHeight"]), fDpiY)));
                FormAutoResize(size);
            }
        }

        public void InitTemplate(string strBillTypeCode)
        {
            string strSql = "SELECT * FROM BillTemplate WHERE BillTypeCode = '" + strBillTypeCode + "'";
            try
            {
                DataTable dt = DataOperate.GetDataTable(strSql);
                foreach (DataRow dr in dt.Rows)
                {
                    ctxt = new CTextBox
                               {
                                   ContextMenuStrip = null,
                                   IsFlag = dr["IsFlag"].ToString(),
                                   ControlId = Convert.ToInt32(dr["ControlId"]),
                                   Location = new Point(Convert.ToInt32(dr["X"]), Convert.ToInt32(dr["Y"])),
                                   Size = new Size(Convert.ToInt32(dr["Width"]), Convert.ToInt32(dr["Height"])),
                                   ControlName = dr["ControlName"].ToString()
                               };
                    if (ctxt.IsFlag == "1")
                    {
                        ctxtExpressBillCode = ctxt;
                        ctxt.Font = new Font(new FontFamily("宋体"), 9, FontStyle.Bold);
                        ctxt.MaxLength = Convert.ToInt32(dtBillType.Rows[0]["BillCodeLength"]);
                    }
                    panelBillPictrue.Controls.Add(ctxt);
                }
                panelBillPictrue.Controls.Add(pbxBillPicture);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "软件提示");
            }
        }

        public void InitText(string strBillTypeCode, string strExpressBillCode)
        {
            string strSql = "SELECT * FROM BillText WHERE BillTypeCode = '" + strBillTypeCode +
                            "' AND ExpressBillCode = '" + strExpressBillCode + "'";
            try
            {
                DataTable dataTable = DataOperate.GetDataTable(strSql);
                List<CTextBox> cTextBoxes = GetCTextBoxes(panelBillPictrue);
                foreach (DataRow dataRow in dataTable.Rows)
                {
                    CTextBox ctxtTemp =
                        cTextBoxes.Find(number => number.ControlId == Convert.ToInt32(dataRow["ControlId"]));
                    ctxtTemp.Text = dataRow["ControlText"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "软件提示");
            }
        }

        public void DisposeAllCTextBoxes(Control control)
        {
            Control.ControlCollection controls = control.Controls;
            int intCount = controls.Count;
            for (int i = 0; i < intCount; i++)
            {
                if (controls[i].GetType() == typeof (CTextBox))
                {
                    controls[i].Dispose();
                    i -= 1;
                    intCount -= 1;
                }
                if (controls[i].GetType() == typeof (GroupBox))
                {
                    DisposeAllCTextBoxes(controls[i]);
                }
            }
        }

        private float MillimetersToPixel(float fValue, float fDpi)
        {
            return (fValue/25.4f)*fDpi;
        }

        public void FormAutoResize(Size size)
        {
            int intOldWidth = Width;
            int intOldHeight = Height;
            Width = size.Width + 50;
            Height = size.Height + 70;
            Location = new Point(Location.X - (Width - intOldWidth)/2, Location.Y - (Height - intOldHeight)/2);
        }

        private void SetValueToDgvr(DataGridViewRow dgvr)
        {
            List<CTextBox> cTextBoxes = GetCTextBoxes(panelBillPictrue);
            DataGridView dataGridView = dgvr.DataGridView;
            DataGridViewColumnCollection dataGridViewColumnCollection = dataGridView.Columns;
            foreach (DataGridViewColumn dataGridViewColumn in dataGridViewColumnCollection)
            {
                dgvr.Cells[dataGridViewColumn.Name].Value =
                    cTextBoxes.First(element => element.ControlId == Convert.ToInt32(dataGridViewColumn.Name)).Text.Trim
                        ();
            }
        }

        private void FormBrowseBill_Load(object sender, EventArgs e)
        {
            formExpressBill = (FormExpressBill) Owner;
            strBillTypeCode = formExpressBill.BillTypeCode;
            strExpressBillCode = formExpressBill.ExpressBillCode;
            fDpiX = CreateGraphics().DpiX;
            fDpiY = CreateGraphics().DpiY;
            dtBillType =
                DataOperate.GetDataTable("SELECT * FROM BillType WHERE BillTypeCode = '" + strBillTypeCode + "'");
            InitTemplate(strBillTypeCode);
            if (Tag.ToString() == "Query")
            {
                toolSave.Visible = false;
                toolPrint.Visible = false;
                Text = "查询条件输入";
            }
            else
            {
                toolQuery.Visible = false;
                InitText(strBillTypeCode, strExpressBillCode);
                Text = "单据打印";
            }
        }

        private void pbxBillPicture_Paint(object sender, PaintEventArgs e)
        {
            DrawImage(e.Graphics);
        }

        private void toolQuery_Click(object sender, EventArgs e)
        {
            string strSql = String.Empty;
            SqlParameter param = new SqlParameter("@BillTypeCode", SqlDbType.VarChar) {Value = strBillTypeCode};
            List<SqlParameter> parameters = new List<SqlParameter> {param};
            SqlParameter[] inputParameters = parameters.ToArray();
            DataTable dt = DataOperate.GetDataTable("QueryExpressBill", inputParameters);
            List<CTextBox> ctxts = GetCTextBoxes(panelBillPictrue);
            foreach (CTextBox ctxtTemp in ctxts)
            {
                if (!(String.IsNullOrEmpty(ctxtTemp.Text.Trim())))
                {
                    if (String.IsNullOrEmpty(strSql))
                    {
                        strSql = "[" + ctxtTemp.ControlId.ToString() + "] LIKE '%" + ctxtTemp.Text.Trim() + "%'";
                    }
                    else
                    {
                        strSql += " AND [" + ctxtTemp.ControlId.ToString() + "] LIKE '%" + ctxtTemp.Text.Trim() + "%'";
                    }
                }
            }
            dt.DefaultView.RowFilter = strSql;
            formExpressBill.dgvExpressBill.DataSource = dt.DefaultView;
            Close();
        }

        private void toolSave_Click(object sender, EventArgs e)
        {
            List<string> strSqls = new List<string>();
            List<CTextBox> ctxts = GetCTextBoxes(panelBillPictrue);
            foreach (CTextBox ctxtTemp in ctxts)
            {
                if (ctxtTemp.IsFlag == "1")
                {
                    if (String.IsNullOrEmpty(ctxtTemp.Text.Trim()))
                    {
                        MessageBox.Show("单据号不许为空！", "软件提示");
                        ctxtTemp.Focus();
                        return;
                    }
                    else
                    {
                        if (ctxtTemp.Text.Trim().Length != ctxtTemp.MaxLength)
                        {
                            MessageBox.Show("单据号位数不正确！", "软件提示");
                            ctxtTemp.Focus();
                            return;
                        }
                    }
                    if (strExpressBillCode != ctxtTemp.Text.Trim())
                    {
                        if (CommonClass.IsExistExpressBillCode(ctxtTemp.Text.Trim(), strBillTypeCode))
                        {
                            MessageBox.Show("该单据号已经存在！", "软件提示");
                            ctxtTemp.Focus();
                            return;
                        }
                    }
                }
                else
                {
                    if (String.IsNullOrEmpty(ctxtTemp.Text.Trim()))
                    {
                        if (
                            MessageBox.Show(ctxtTemp.ControlName + "为空，是否继续", "软件提示", MessageBoxButtons.YesNo,
                                            MessageBoxIcon.Exclamation) == DialogResult.No)
                        {
                            ctxtTemp.Focus();
                            return;
                        }
                    }
                }
                string strSql = "UPDATE BillText SET ExpressBillCode = '" + ctxtExpressBillCode.Text.Trim() +
                                "',ControlText = '" + ctxtTemp.Text.Trim() + "' WHERE BillTypeCode = '" +
                                strBillTypeCode + "' AND ExpressBillCode = '" + strExpressBillCode +
                                "' AND ControlId = '" + ctxtTemp.ControlId + "'";
                strSqls.Add(strSql);
            }
            if (strSqls.Count > 0)
            {
                if (DataOperate.ExecDataBySqls(strSqls))
                {
                    MessageBox.Show("保存成功！", "软件提示");
                    SetValueToDgvr(formExpressBill.dgvExpressBill.CurrentRow);
                }
                else
                {
                    MessageBox.Show("保存失败!", "软件提示");
                }
            }
        }

        private void toolPrint_Click(object sender, EventArgs e)
        {
            Margins margin = new Margins(0, 0, 0, 0);
            pd.DefaultPageSettings.Margins = margin;
            PaperSize pageSize = new PaperSize("快递单打印",
                                               Convert.ToInt32(
                                                   MillimetersToPixel(Convert.ToInt32(dtBillType.Rows[0]["BillWidth"]),
                                                                      fDpiX)),
                                               Convert.ToInt32(
                                                   MillimetersToPixel(
                                                       Convert.ToInt32(dtBillType.Rows[0]["BillHeight"]), fDpiY)));
            pd.DefaultPageSettings.PaperSize = pageSize;
            pd.Print();
        }

        private void toolExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pd_PrintPage(object sender, PrintPageEventArgs e)
        {
            Graphics graphics = e.Graphics;
            Font font = new Font("宋体", 12, GraphicsUnit.Pixel);
            Brush brush = new SolidBrush(Color.Black);
            List<CTextBox> ctxts = GetCTextBoxes(panelBillPictrue);
            foreach (CTextBox ctxtTemp in ctxts)
            {
                graphics.DrawString(ctxtTemp.Text, font, brush, ctxtTemp.Location.X, ctxtTemp.Location.Y);
            }
        }
    }
}