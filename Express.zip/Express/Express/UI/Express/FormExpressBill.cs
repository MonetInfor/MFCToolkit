﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Express.Common;
using Express.DAL;

namespace Express.UI.Express
{
    public partial class FormExpressBill : Form
    {
        private readonly IDictionary<int, object> dicKeyValue = new Dictionary<int, object>();
        private string billTypeCode;
        private string expressBillCode;
        private string strExpressBillCodeColumn;

        public FormExpressBill()
        {
            InitializeComponent();
        }

        public string BillTypeCode
        {
            get { return billTypeCode; }
        }

        public string ExpressBillCode
        {
            get { return expressBillCode; }
        }

        private void FormExpressBill_Load(object sender, EventArgs e)
        {
            DataTable dt = DataOperate.GetDataTable("SELECT BillTypeCode, BillTypeName FROM BillType");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                toolcbxBillTypeCode.Items.Insert(i, dt.Rows[i]["BillTypeName"]);
                dicKeyValue.Add(i, dt.Rows[i]["BillTypeCode"]);
            }
            if (toolcbxBillTypeCode.Items.Count > 0)
            {
                toolcbxBillTypeCode.SelectedIndex = 0;
            }
        }

        private void toolcbxBillType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (toolcbxBillTypeCode.Items.Count > 0)
            {
                dgvExpressBill.DataSource = null;
                dgvExpressBill.Columns.Clear();
                billTypeCode = dicKeyValue[toolcbxBillTypeCode.SelectedIndex].ToString();
                DataTable dataTable =
                    DataOperate.GetDataTable("SELECT * FROM BillTemplate WHERE BillTypeCode = '" + billTypeCode + "'");
                if (dataTable.Rows.Count > 0)
                {
                    DataRow drBillCode =
                        dataTable.AsEnumerable().FirstOrDefault(itm => itm.Field<string>("IsFlag") == "1");
                    if (drBillCode != null)
                    {
                        strExpressBillCodeColumn = drBillCode["ControlId"].ToString();
                        dgvExpressBill.Columns.Add(strExpressBillCodeColumn, drBillCode["ControlName"].ToString());
                        dgvExpressBill.Columns[strExpressBillCodeColumn].DataPropertyName = strExpressBillCodeColumn;
                        dgvExpressBill.Columns[strExpressBillCodeColumn].ReadOnly = true;
                        foreach (DataRow dataRow in dataTable.Rows)
                        {
                            if (dataRow["IsFlag"].ToString() == "0")
                            {
                                string strColumnName = dataRow["ControlId"].ToString();
                                dgvExpressBill.Columns.Add(strColumnName, dataRow["ControlName"].ToString());
                                dgvExpressBill.Columns[strColumnName].DataPropertyName = strColumnName;
                                dgvExpressBill.Columns[strColumnName].ReadOnly = true;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("该单据的模板未设置快递单号输入框，无法查询！", "信息提示");
                    }
                }
            }
        }

        private void toolQuery_Click(object sender, EventArgs e)
        {
            if (dgvExpressBill.Columns.Count > 0)
            {
                CommonClass.ShowDialogForm(typeof (FormBrowseBill), "Query", this);
            }
        }

        private void toolPrint_Click(object sender, EventArgs e)
        {
            if (dgvExpressBill.RowCount > 0)
            {
                expressBillCode = dgvExpressBill.CurrentRow.Cells[strExpressBillCodeColumn].Value.ToString();
                CommonClass.ShowDialogForm(typeof (FormBrowseBill), "Print", this);
            }
        }

        private void toolDelete_Click(object sender, EventArgs e)
        {
            if (dgvExpressBill.RowCount > 0)
            {
                if (MessageBox.Show("确定要删除吗？", "软件提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) ==
                    DialogResult.Yes)
                {
                    expressBillCode = dgvExpressBill.CurrentRow.Cells[strExpressBillCodeColumn].Value.ToString();
                    string strSql = "DELETE FROM BillText WHERE BillTypeCode = '" + billTypeCode +
                                    "' AND ExpressBillCode = '" + expressBillCode + "'";
                    if (DataOperate.ExecDataBySql(strSql) > 0)
                    {
                        dgvExpressBill.Rows.Remove(dgvExpressBill.CurrentRow);
                        MessageBox.Show("删除成功！", "软件提示");
                    }
                    else
                    {
                        MessageBox.Show("删除失败！", "软件提示");
                    }
                }
            }
        }

        private void toolExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dgvExpressBill_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            toolPrint_Click(sender, e);
        }
    }
}