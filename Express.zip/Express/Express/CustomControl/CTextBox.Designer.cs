﻿namespace Express.CustomControl
{
    partial class CTextBox
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuOperate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolDeleteCTextBox = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolSetFlag = new System.Windows.Forms.ToolStripMenuItem();
            this.toolSetProperty = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuOperate.SuspendLayout();
            this.SuspendLayout();

            this.contextMenuOperate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolDeleteCTextBox,
            this.toolStripSeparator1,
            this.toolSetFlag,
            this.toolSetProperty});
            this.contextMenuOperate.Name = "contextMenuStrip1";
            this.contextMenuOperate.Size = new System.Drawing.Size(131, 76);

            this.toolDeleteCTextBox.Name = "toolDeleteCTextBox";
            this.toolDeleteCTextBox.Size = new System.Drawing.Size(130, 22);
            this.toolDeleteCTextBox.Text = "删除输入框";
            this.toolDeleteCTextBox.Click += new System.EventHandler(this.toolDeleteCTextBox_Click);

            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(115, 6);

            this.toolSetFlag.Name = "toolSetFlag";
            this.toolSetFlag.Size = new System.Drawing.Size(118, 22);
            this.toolSetFlag.Visible = false;
            this.toolSetFlag.Click += new System.EventHandler(this.toolSetFlag_Click);

            this.toolSetProperty.Name = "toolSetProperty";
            this.toolSetProperty.Size = new System.Drawing.Size(130, 22);
            this.toolSetProperty.Text = "设置属性";
            this.toolSetProperty.Click += new System.EventHandler(this.toolSetProperty_Click);

            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ContextMenuStrip = this.contextMenuOperate;
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.CTextBox_MouseMove);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CTextBox_MouseDown);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CTextBox_MouseUp);
            this.contextMenuOperate.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.ContextMenuStrip contextMenuOperate;
        private System.Windows.Forms.ToolStripMenuItem toolSetFlag;
        private System.Windows.Forms.ToolStripMenuItem toolDeleteCTextBox;
        private System.Windows.Forms.ToolStripMenuItem toolSetProperty;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    }
}
