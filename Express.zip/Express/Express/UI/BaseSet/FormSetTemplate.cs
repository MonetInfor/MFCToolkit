﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Express.Common;
using Express.CustomControl;
using Express.DAL;

namespace Express.UI.BaseSet
{
    public partial class FormSetTemplate : Form
    {
        private CTextBox ctxt;
        private DataGridViewRow dgvrBillType;
        private float fDpiX;
        private float fDpiY;
        private FormBillType formBillType;
        private Point offset;

        public FormSetTemplate()
        {
            InitializeComponent();
        }

        public List<CTextBox> GetCTextBoxes(Control control)
        {
            List<CTextBox> ctxts = new List<CTextBox>();
            foreach (Control con in control.Controls)
            {
                if (con.GetType() == typeof (CTextBox))
                {
                    ctxts.Add((CTextBox) con);
                }
                if (con.GetType() == typeof (GroupBox))
                {
                    GetCTextBoxes(con);
                }
            }
            return ctxts;
        }

        public void DisposeAllCTextBoxes(Control ctrl)
        {
            Control.ControlCollection ctrls = ctrl.Controls;
            int intCount = ctrls.Count;
            for (int i = 0; i < intCount; i++)
            {
                if (ctrls[i].GetType() == typeof (CTextBox))
                {
                    ctrls[i].Dispose();
                    i -= 1;
                    intCount -= 1;
                }
                if (i >= 0)
                {
                    if (ctrls[i].GetType() == typeof (GroupBox))
                    {
                        DisposeAllCTextBoxes(ctrls[i]);
                    }
                }
            }
        }

        public void InitTemplate(string strBillTypeCode)
        {
            string strSql = "SELECT * FROM BillTemplate WHERE BillTypeCode = '" + strBillTypeCode + "'";
            try
            {
                DataTable dt = DataOperate.GetDataTable(strSql);
                foreach (DataRow dr in dt.Rows)
                {
                    ctxt = new CTextBox
                               {
                                   IsFlag = dr["IsFlag"].ToString(),
                                   Text = dr["ControlName"].ToString(),
                                   ControlId = Convert.ToInt32(dr["ControlId"]),
                                   FormParent = this,
                                   DefaultValue = dr["DefaultValue"].ToString(),
                                   ControlName = dr["ControlName"].ToString(),
                                   TurnControlName = dr["TurnControlName"].ToString(),
                                   Location = new Point(Convert.ToInt32(dr["X"]), Convert.ToInt32(dr["Y"])),
                                   Size = new Size(Convert.ToInt32(dr["Width"]), Convert.ToInt32(dr["Height"])),
                                   ReadOnly = true
                               };
                    Controls.Add(ctxt);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "软件提示");
            }
        }

        public void FormAutoResize(Size size)
        {
            int intOldWidth = Width;
            int intOldHeight = Height;

            Width = size.Width + 50;
            Height = size.Height + 70;

            Location = new Point(Location.X - (Width - intOldWidth)/2, Location.Y - (Height - intOldHeight)/2);
        }

        private void FormSetTemplate_MouseMove(object sender, MouseEventArgs e)
        {
            List<CTextBox> ctxts = GetCTextBoxes(this);
            foreach (CTextBox ctxt in ctxts)
            {
                if (e.X == ctxt.Location.X + ctxt.Size.Width)
                {
                    ctxt.Cursor = Cursors.SizeWE;
                }
                else
                {
                    ctxt.Cursor = Cursors.SizeAll;
                }
            }
        }

        private void toolAddCTextBox_Click(object sender, EventArgs e)
        {
            ctxt = new CTextBox
                       {
                           IsFlag = "0",
                           ControlId = 0,
                           FormParent = this,
                           Location = new Point(MousePosition.X - offset.X, MousePosition.Y - offset.Y),
                           ReadOnly = true,
                           BackColor = Color.Red
                       };
            Controls.Add(ctxt);
            ctxt.Focus();
            ctxt.SelectAll();
        }

        private void FormSetTemplate_Load(object sender, EventArgs e)
        {
            fDpiX = CreateGraphics().DpiX;
            fDpiY = CreateGraphics().DpiY;
            formBillType = (FormBillType) Owner;
            dgvrBillType = formBillType.dgvBillType.CurrentRow;
            InitTemplate(dgvrBillType.Cells["BillTypeCode"].Value.ToString());
        }

        private void FormSetTemplate_Paint(object sender, PaintEventArgs e)
        {
            offset = new Point(Location.X, Location.Y);
            Image img = CommonClass.GetImageByBytes(dgvrBillType.Cells["BillPicture"].Value as byte[]);
            Point point = new Point(0, 0);
            SizeF newSize = new SizeF(
                MillimetersToPixel(Convert.ToInt32(dgvrBillType.Cells["BillWidth"].Value), fDpiX),
                MillimetersToPixel(Convert.ToInt32(dgvrBillType.Cells["BillHeight"].Value), fDpiY));
            RectangleF NewRect = new RectangleF(point, newSize);
            SizeF oldSize = new SizeF(img.Width, img.Height);
            RectangleF OldRect = new RectangleF(point, oldSize);
            e.Graphics.DrawImage(img, NewRect, OldRect, GraphicsUnit.Pixel);
            if (newSize.Width > Width || newSize.Height > Height)
            {
                Size size =
                    new Size(
                        Convert.ToInt32(MillimetersToPixel(Convert.ToInt32(dgvrBillType.Cells["BillWidth"].Value), fDpiX)),
                        Convert.ToInt32(MillimetersToPixel(Convert.ToInt32(dgvrBillType.Cells["BillHeight"].Value),
                                                           fDpiY)));
                FormAutoResize(size);
            }
        }

        private float MillimetersToPixel(float fValue, float fDPI)
        {
            return (fValue/25.4f)*fDPI;
        }

        private void GetResultIntoImage(ref Image img, string strUserName, string strAddress, string strPhoneNumber)
        {
            Graphics g = Graphics.FromImage(img);
            Font f = new Font("宋体", 12, GraphicsUnit.Pixel);
            Brush b = new SolidBrush(Color.Black);
            g.DrawImage(img, 0, 0, img.Width, img.Height);
            DataTable dt = DataOperate.GetDataTable("SELECT * FROM Template");
            foreach (DataRow dr in dt.Rows)
            {
                g.DrawString(strUserName, f, b, Convert.ToInt32(dt.Rows[2]["X"]), Convert.ToInt32(dt.Rows[2]["Y"]));
                g.DrawString(strAddress, f, b, Convert.ToInt32(dt.Rows[0]["X"]), Convert.ToInt32(dt.Rows[0]["Y"]));
                g.DrawString(strPhoneNumber, f, b, Convert.ToInt32(dt.Rows[1]["X"]), Convert.ToInt32(dt.Rows[1]["Y"]));
            }
        }

        private void toolSave_Click(object sender, EventArgs e)
        {
            bool boolIsFlag = false;
            string strSql = null;
            string strBillTypeCode = dgvrBillType.Cells["BillTypeCode"].Value.ToString();
            List<string> strSqls = new List<string>();
            List<CTextBox> ctxts = GetCTextBoxes(this);
            foreach (CTextBox ctxt in ctxts)
            {
                if (ctxt.IsFlag == "1")
                {
                    boolIsFlag = true;
                }
                if (ctxt.ControlId == 0)
                {
                    strSql =
                        "INSERT INTO BillTemplate (BillTypeCode, X, Y, Width, Height, IsFlag, ControlName, DefaultValue, TurnControlName) VALUES ('" +
                        strBillTypeCode + "','" + ctxt.Location.X + "','" + ctxt.Location.Y + "','" + ctxt.Width + "','" +
                        ctxt.Height + "','" + ctxt.IsFlag + "','" + ctxt.ControlName + "','" + ctxt.DefaultValue + "','" +
                        ctxt.TurnControlName + "')";
                }
                else
                {
                    strSql = "UPDATE BillTemplate SET BillTypeCode = '" + strBillTypeCode + "', X = '" + ctxt.Location.X +
                             "', Y = '" + ctxt.Location.Y + "', Width = '" + ctxt.Width + "', Height = '" + ctxt.Height +
                             "', IsFlag = '" + ctxt.IsFlag + "', ControlName = '" + ctxt.ControlName +
                             "', DefaultValue = '" + ctxt.DefaultValue + "', TurnControlName = '" + ctxt.TurnControlName +
                             "' WHERE ControlId = '" + ctxt.ControlId + "'";
                }
                strSqls.Add(strSql);
            }

            if (!boolIsFlag)
            {
                if (e.GetType() == typeof (FormClosingEventArgs))
                {
                    ((FormClosingEventArgs) e).Cancel = true;
                }
                MessageBox.Show("请设置快递单号输入框，否则程序无法保存！", "软件提示");
                return;
            }

            if (strSqls.Count > 0)
            {
                if (MessageBox.Show("确定要保存吗？", "软件提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) ==
                    DialogResult.Yes)
                {
                    if (DataOperate.ExecDataBySqls(strSqls))
                    {
                        DisposeAllCTextBoxes(this);
                        InitTemplate(strBillTypeCode);
                        MessageBox.Show("保存模板成功！", "软件提示");
                    }
                    else
                    {
                        MessageBox.Show("保存模板失败！", "软件提示");
                    }
                }
            }
            else
            {
                MessageBox.Show("未添加输入框，无需保存！", "软件提示");
            }
        }

        private void toolExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void FormSetTemplate_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = false;
            List<CTextBox> ctxts = GetCTextBoxes(this);
            if (ctxts.Exists(itm => itm.BackColor == Color.Red))
            {
                if (MessageBox.Show("模板设置信息已被更新，是否保存？", "软件提示", MessageBoxButtons.YesNo, MessageBoxIcon.Information) ==
                    DialogResult.Yes)
                {
                    toolSave_Click(sender, e);
                }
            }
        }

        private void FormSetTemplate_FormClosed(object sender, FormClosedEventArgs e)
        {
            Dispose();
        }
    }
}