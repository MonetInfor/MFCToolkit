﻿using System;
using System.Windows.Forms;
using Express.Common;

namespace Express.UI.BaseSet
{
    public partial class FormOperator : Form
    {
        public FormOperator()
        {
            InitializeComponent();
        }

        private void FormOperator_Load(object sender, EventArgs e)
        {
            bsOperator.DataSource = CommonClass.GetDataTable("Operator", "");
            dgvOperator.DataSource = bsOperator;
        }

        private void toolAdd_Click(object sender, EventArgs e)
        {
            CommonClass.ShowDialogForm(typeof (FormOperatorInput), "Add", this);
        }

        private void toolAmend_Click(object sender, EventArgs e)
        {
            if (dgvOperator.RowCount > 0)
            {
                CommonClass.ShowDialogForm(typeof (FormOperatorInput), "Edit", this);
            }
        }

        private void toolDelete_Click(object sender, EventArgs e)
        {
            if (dgvOperator.RowCount == 0 || dgvOperator.CurrentRow.Cells["IsFlag"].Value.ToString() == "1")
            {
                return;
            }
            if (MessageBox.Show("确定要删除吗？", "软件提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) ==
                DialogResult.Yes)
            {
                DataGridViewRow dataGridViewRow = dgvOperator.CurrentRow;
                dgvOperator.Rows.Remove(dataGridViewRow);
                MessageBox.Show(CommonClass.Commit(dgvOperator, bsOperator) ? "删除成功！" : "删除失败！", "软件提示");
            }
        }

        private void toolExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dgvOperator_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            toolAmend_Click(sender, e);
        }
    }
}