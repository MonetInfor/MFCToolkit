﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Express.Common;
using Express.DAL;
using Express.UI.BaseSet;

namespace Express.CustomControl
{
    public partial class CTextBox : TextBox
    {
        private int controlId;
        private string controlName;
        private string defaultValue;
        private Form formParent;
        private int intWidth;
        private string isFlag;
        private bool isMoving;
        private Point offset;
        private string turnControlName;
         

        public CTextBox()
        {
            InitializeComponent();
        }

        public string IsFlag
        {
            get { return isFlag; }
            set { isFlag = value; }
        }

        public Form FormParent
        {
            get { return formParent; }
            set { formParent = value; }
        }

        
        public int ControlId
        {
            get { return controlId; }
            set { controlId = value; }
        }

        public string ControlName
        {
            get { return controlName; }
            set { controlName = value; }
        }

        public string TurnControlName
        {
            get { return turnControlName; }
            set { turnControlName = value; }
        }

        public string DefaultValue
        {
            get { return defaultValue; }
            set { defaultValue = value; }
        }

        private void CTextBox_MouseDown(object sender, MouseEventArgs e)
        {
            isMoving = true;
            offset = new Point(e.X, e.Y);
            intWidth = Width;
        }

        public List<CTextBox> GetCTextBoxes(Control control)
        {
            List<CTextBox> cTextBoxes = new List<CTextBox>();
            foreach (Control c in control.Controls)
            {
                if (c.GetType() == typeof (CTextBox))
                {
                    cTextBoxes.Add((CTextBox) c);
                }
                if (c.GetType() == typeof (GroupBox))
                {
                    GetCTextBoxes(c);
                }
            }
            return cTextBoxes;
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);
        }

        private void CTextBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMoving)
            {
                if (Cursor == Cursors.SizeAll)
                {
                    Location = new Point(Location.X + (e.X - offset.X),
                                         Location.Y + (e.Y - offset.Y));
                    BackColor = Color.Red;
                }
                if (Cursor == Cursors.SizeWE)
                {
                    Width = intWidth + (e.X - offset.X);
                    BackColor = Color.Red;
                }
            }
        }

        private void CTextBox_MouseUp(object sender, MouseEventArgs e)
        {
            isMoving = false;
        }

        private void toolDeleteCTextBox_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定要删除吗？", "软件提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) ==
                DialogResult.Yes)
            {
                if (ControlId != 0)
                {
                    try
                    {
                        if (CommonClass.IsExistConstraint("BillTemplate", ControlId.ToString()))
                        {
                            if (
                                MessageBox.Show("该输入框已生成快递单数据，若继续执行将删除与之相关的数据，是否继续执行？", "软件提示", MessageBoxButtons.YesNo,
                                                MessageBoxIcon.Exclamation) == DialogResult.No)
                            {
                                return;
                            }
                        }
                        if (
                            DataOperate.ExecDataBySql("DELETE FROM tb_BillTemplate WHERE ControlId = '" + ControlId +
                                                      "'") == 0)
                        {
                            MessageBox.Show("删除失败！", "软件提示");
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "软件提示");
                        return;
                    }
                }
                Dispose();
                MessageBox.Show("删除成功！", "软件提示");
            }
        }

        private void toolSetFlag_Click(object sender, EventArgs e)
        {
            List<CTextBox> cTextBoxes = GetCTextBoxes(FormParent);
            foreach (CTextBox ctxt in cTextBoxes)
            {
                if (ctxt.IsFlag == "1")
                {
                    ctxt.Text = "请输入名称";
                }
                ctxt.IsFlag = "0";
            }
            IsFlag = "1";
            Text = "快递单号输入框";
        }

        private void toolSetProperty_Click(object sender, EventArgs e)
        {
            CommonClass.ShowDialogForm(typeof (FormSetProperty), this, FormParent);
        }
    }
}